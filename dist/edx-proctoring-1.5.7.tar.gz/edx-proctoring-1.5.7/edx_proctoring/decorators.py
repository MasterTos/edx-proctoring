"""
The custom decorators for the REST API.
"""
